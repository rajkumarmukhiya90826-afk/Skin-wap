package com.skinswap.app

import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.documentfile.provider.DocumentFile
import org.json.JSONObject
import java.io.File
import java.util.concurrent.Executors
import java.util.zip.ZipInputStream

class MainActivity : Activity() {

    private data class Existing(val doc: DocumentFile, val name: String, val uuid: String?)
    private data class PackInfo(val prefix: String, val name: String, val uuid: String?, val type: String?)

    private val reqTree = 101
    private val reqPack = 102
    private val mcBedrock = "com.mojang.minecraftpe"
    private val mcEdu = "com.microsoft.minecraftedu"
    private val io = Executors.newSingleThreadExecutor()

    private val RED = 0xFFE53935.toInt()
    private val DARK_RED = 0xFFB71C1C.toInt()
    private val BLACK = Color.BLACK
    private val WHITE = Color.WHITE
    private val GREY = 0xFFBDBDBD.toInt()

    private lateinit var statusView: TextView
    private lateinit var packView: TextView
    private lateinit var logView: TextView
    private lateinit var logScroll: ScrollView
    private lateinit var spinner: Spinner

    private var treeUri: Uri? = null
    private var packUri: Uri? = null
    private var skinDir: DocumentFile? = null
    private var existing: List<Existing> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()

        val saved = getSharedPreferences("skinswap", MODE_PRIVATE).getString("tree", null)
        if (saved != null) {
            val u = Uri.parse(saved)
            val ok = contentResolver.persistedUriPermissions.any { it.uri == u && it.isWritePermission }
            if (ok) {
                treeUri = u
                refreshFolder()
            }
        }
    }

    // ---------------------------------------------------------------- UI

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(s: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = s
        textSize = size
        setTextColor(color)
        gravity = Gravity.CENTER_HORIZONTAL
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        setPadding(0, dp(4), 0, dp(4))
    }

    private fun button(s: String, bg: Int, size: Float = 15f, onClick: () -> Unit) = Button(this).apply {
        text = s
        textSize = size
        transformationMethod = null
        setTextColor(WHITE)
        setBackgroundColor(bg)
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(8) }
        setOnClickListener { onClick() }
    }

    private fun buildUi() {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(20), dp(18), dp(20))
            setBackgroundColor(BLACK)
        }

        col.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_logo)
            layoutParams = LinearLayout.LayoutParams(dp(96), dp(96)).apply {
                gravity = Gravity.CENTER_HORIZONTAL
            }
        })
        col.addView(label("SkinSwap", 28f, RED, bold = true))
        col.addView(label("Made by itsmcboy", 13f, GREY))
        col.addView(label("Replace Minecraft Bedrock skin packs with 4D skin packs", 12f, GREY))

        col.addView(label("STEP 1 — Choose skin_packs folder", 14f, RED, bold = true))
        statusView = label("Folder: not selected", 13f, WHITE)
        col.addView(button("Choose skin_packs folder", DARK_RED) { pickTree() })
        col.addView(statusView)

        col.addView(label("STEP 2 — Choose 4D skin pack (.mcpack / .zip)", 14f, RED, bold = true))
        packView = label("Pack: not selected", 13f, WHITE)
        col.addView(button("Choose skin pack file", DARK_RED) { pickPack() })
        col.addView(packView)

        col.addView(label("STEP 3 — Which pack to replace?", 14f, RED, bold = true))
        spinner = Spinner(this).apply {
            setBackgroundColor(0xFFEEEEEE.toInt())
            adapter = ArrayAdapter(
                this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("Add as new (replace nothing)")
            )
        }
        col.addView(spinner)

        col.addView(button("INSTALL / REPLACE", RED, 16f) { install() })
        col.addView(button("Fallback: import via Minecraft", DARK_RED) { importViaMinecraft() })
        col.addView(button("PLAY", RED, 20f) { showPlayOptions() })

        col.addView(label("Log", 13f, RED, bold = true))
        logView = label("", 12f, WHITE).apply { gravity = Gravity.START }
        logScroll = ScrollView(this).apply {
            addView(logView)
            setBackgroundColor(0xFF1A1A1A.toInt())
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(200)
            )
        }
        col.addView(logScroll)

        setContentView(ScrollView(this).apply {
            setBackgroundColor(BLACK)
            addView(col)
        })
    }

    private fun log(msg: String) = runOnUiThread {
        logView.append(msg + "\n")
        logScroll.post { logScroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun toast(msg: String) = runOnUiThread {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    }

    // ---------------------------------------------------------------- PLAY

    private fun isInstalled(pkg: String) = try {
        packageManager.getPackageInfo(pkg, 0)
        true
    } catch (e: Exception) {
        false
    }

    private data class PlayOption(val label: String, val pkg: String, val icon: android.graphics.drawable.Drawable)

    // Finds every installed launcher app whose name or package looks like a Minecraft client
    // (Bedrock, Education, Flarial, LeviLauncher, etc.)
    private fun findClients(): List<PlayOption> {
        val keys = listOf("minecraft", "mojang", "flarial", "levi")
        val apps = packageManager.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
        )
        val seen = HashSet<String>()
        val result = mutableListOf<PlayOption>()
        for (ri in apps) {
            val pkg = ri.activityInfo.packageName
            if (!seen.add(pkg)) continue
            val label = ri.loadLabel(packageManager).toString()
            val hit = keys.any { label.contains(it, ignoreCase = true) || pkg.contains(it, ignoreCase = true) }
            if (hit) result.add(PlayOption(label, pkg, ri.loadIcon(packageManager)))
        }
        return result
    }

    private fun launchPackage(pkg: String, name: String) {
        val intent = packageManager.getLaunchIntentForPackage(pkg)
        if (intent != null) startActivity(intent) else toast("Could not open $name")
    }

    private fun showPlayOptions() {
        val clients = findClients()

        // No other client installed (only Bedrock, or nothing): open Bedrock directly
        val nonBedrock = clients.filter { it.pkg != mcBedrock }
        if (nonBedrock.isEmpty()) {
            val bedrock = clients.firstOrNull { it.pkg == mcBedrock }
            if (bedrock != null) launchPackage(bedrock.pkg, bedrock.label)
            else toast("Minecraft is not installed on this phone")
            return
        }

        // Other clients present: ask which one to open, with their icons
        val adapter = object : ArrayAdapter<PlayOption>(this, 0, clients) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val opt = getItem(position)!!
                val row = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(16), dp(12), dp(16), dp(12))
                }
                row.addView(ImageView(this@MainActivity).apply {
                    setImageDrawable(opt.icon)
                    layoutParams = LinearLayout.LayoutParams(dp(44), dp(44))
                })
                row.addView(TextView(this@MainActivity).apply {
                    text = opt.label
                    textSize = 17f
                    setTextColor(WHITE)
                    setPadding(dp(16), 0, 0, 0)
                })
                return row
            }
        }

        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog)
            .setTitle("Which client do you want to play?")
            .setAdapter(adapter) { _, which -> launchPackage(clients[which].pkg, clients[which].label) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ---------------------------------------------------------------- pickers

    private fun pickTree() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
            addFlags(
                Intent.FLAG_GRANT_READ_URI_PERMISSION or
                    Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                    Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION or
                    Intent.FLAG_GRANT_PREFIX_URI_PERMISSION
            )
            if (Build.VERSION.SDK_INT >= 26) {
                putExtra(
                    DocumentsContract.EXTRA_INITIAL_URI,
                    DocumentsContract.buildDocumentUri(
                        "com.android.externalstorage.documents",
                        "primary:Android/data/$mcBedrock/files/games/com.mojang/skin_packs"
                    )
                )
            }
        }
        try {
            startActivityForResult(i, reqTree)
        } catch (e: Exception) {
            toast("Folder picker could not open: ${e.message}")
        }
    }

    private fun pickPack() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        startActivityForResult(i, reqPack)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data?.data == null) return
        val uri = data.data!!

        when (requestCode) {
            reqTree -> {
                try {
                    contentResolver.takePersistableUriPermission(
                        uri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                    )
                } catch (_: Exception) {
                }
                treeUri = uri
                getSharedPreferences("skinswap", MODE_PRIVATE).edit()
                    .putString("tree", uri.toString()).apply()
                refreshFolder()
            }

            reqPack -> {
                packUri = uri
                packView.text = "Pack: ${queryName(uri) ?: uri.lastPathSegment}"
            }
        }
    }

    private fun queryName(uri: Uri): String? = try {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        }
    } catch (_: Exception) {
        null
    }

    // ---------------------------------------------------------------- folder

    private fun resolveSkinPacks(uri: Uri): DocumentFile? {
        val root = DocumentFile.fromTreeUri(this, uri) ?: return null
        if (root.name == "skin_packs") return root

        root.findFile("skin_packs")?.takeIf { it.isDirectory }?.let { return it }
        root.findFile("com.mojang")?.findFile("skin_packs")?.takeIf { it.isDirectory }?.let { return it }
        root.findFile("games")?.findFile("com.mojang")?.findFile("skin_packs")
            ?.takeIf { it.isDirectory }?.let { return it }

        if (root.name == "com.mojang") return root.createDirectory("skin_packs")
        return null
    }

    private fun listExisting(dir: DocumentFile): List<Existing> =
        dir.listFiles().filter { it.isDirectory }.map { d ->
            var name = d.name ?: "?"
            var uuid: String? = null
            try {
                val m = d.findFile("manifest.json")
                if (m != null) {
                    val txt = contentResolver.openInputStream(m.uri)?.use {
                        it.readBytes().toString(Charsets.UTF_8)
                    }
                    if (txt != null) {
                        val h = JSONObject(txt.trimStart('﻿')).optJSONObject("header")
                        h?.optString("name")?.takeIf { it.isNotBlank() }?.let { name = it }
                        uuid = h?.optString("uuid")?.takeIf { it.isNotBlank() }
                    }
                }
            } catch (_: Exception) {
            }
            Existing(d, name, uuid)
        }

    private fun refreshFolder() {
        val uri = treeUri ?: return
        io.execute {
            try {
                val dir = resolveSkinPacks(uri)
                if (dir == null) {
                    skinDir = null
                    runOnUiThread {
                        statusView.text = "Folder: skin_packs not found. Choose the com.mojang or skin_packs folder."
                    }
                    log("skin_packs folder not resolved. Check the Android 13+ note in README.")
                    return@execute
                }
                skinDir = dir
                existing = listExisting(dir)
                val items = listOf("Add as new (replace nothing)") +
                    existing.map { "Replace: ${it.name}  [${it.doc.name}]" }
                runOnUiThread {
                    statusView.text = "Folder: OK (${existing.size} packs found)"
                    spinner.adapter = ArrayAdapter(
                        this, android.R.layout.simple_spinner_dropdown_item, items
                    )
                }
            } catch (e: Exception) {
                log("Folder error: ${e.message}")
            }
        }
    }

    // ---------------------------------------------------------------- pack scan + install

    private fun scanPack(uri: Uri): PackInfo {
        var bestPath: String? = null
        var bestText: String? = null

        contentResolver.openInputStream(uri)!!.use { raw ->
            ZipInputStream(raw).use { zis ->
                var e = zis.nextEntry
                while (e != null) {
                    val n = e.name.replace('\\', '/')
                    if (!e.isDirectory && !n.contains("__MACOSX") &&
                        (n == "manifest.json" || n.endsWith("/manifest.json"))
                    ) {
                        val cur = bestPath
                        if (cur == null || n.length < cur.length) {
                            bestPath = n
                            bestText = zis.readBytes().toString(Charsets.UTF_8)
                        }
                    }
                    zis.closeEntry()
                    e = zis.nextEntry
                }
            }
        }

        val path = bestPath ?: throw IllegalStateException("manifest.json not found, this is not a valid skin pack")
        val json = JSONObject((bestText ?: "").trimStart('﻿'))
        val header = json.optJSONObject("header")
        val type = json.optJSONArray("modules")?.optJSONObject(0)?.optString("type")
        return PackInfo(
            prefix = path.removeSuffix("manifest.json"),
            name = header?.optString("name")?.takeIf { it.isNotBlank() } ?: "skinpack",
            uuid = header?.optString("uuid")?.takeIf { it.isNotBlank() },
            type = type
        )
    }

    private fun install() {
        val pack = packUri
        val dir = skinDir
        if (pack == null) { toast("Choose a skin pack file in Step 2 first"); return }
        if (dir == null) { toast("Choose the skin_packs folder in Step 1 first"); return }
        val replaceIdx = spinner.selectedItemPosition - 1

        io.execute {
            try {
                log("Reading pack...")
                val info = scanPack(pack)
                log("Found: ${info.name} (type: ${info.type ?: "unknown"}, uuid: ${info.uuid ?: "none"})")
                if (info.type != null && info.type != "skin_pack") {
                    log("Warning: type is not skin_pack, continuing anyway.")
                }

                val folderName = info.name.replace(Regex("[^A-Za-z0-9._ -]"), "_").trim().ifEmpty { "skinpack" }

                // 1) remove old pack(s)
                val toDelete = mutableListOf<Existing>()
                if (replaceIdx in existing.indices) toDelete.add(existing[replaceIdx])
                existing.forEach { ex ->
                    val same = ex.uuid != null && ex.uuid == info.uuid
                    if ((same || ex.doc.name == folderName) && toDelete.none { it.doc.uri == ex.doc.uri }) {
                        toDelete.add(ex)
                    }
                }
                toDelete.forEach {
                    log("Removing: ${it.doc.name}")
                    if (!it.doc.delete()) log("Could not delete: ${it.doc.name}")
                }

                // 2) create new folder
                val target = dir.createDirectory(folderName)
                    ?: throw IllegalStateException("Could not create folder. Check permission.")

                val dirCache = HashMap<String, DocumentFile>()
                dirCache[""] = target
                fun dirFor(path: String): DocumentFile? {
                    dirCache[path]?.let { return it }
                    val parent = dirFor(path.substringBeforeLast('/', "")) ?: return null
                    val name = path.substringAfterLast('/')
                    val d = parent.findFile(name) ?: parent.createDirectory(name)
                    if (d != null) dirCache[path] = d
                    return d
                }

                // 3) extract files
                var count = 0
                val written = mutableListOf<String>()
                contentResolver.openInputStream(pack)!!.use { raw ->
                    ZipInputStream(raw).use { zis ->
                        var e = zis.nextEntry
                        while (e != null) {
                            val n = e.name.replace('\\', '/')
                            if (n.startsWith(info.prefix) && !n.contains("__MACOSX")) {
                                val rel = n.removePrefix(info.prefix)
                                if (rel.isNotEmpty() && rel.split('/').none { it == ".." }) {
                                    if (e.isDirectory) {
                                        dirFor(rel.trimEnd('/'))
                                    } else {
                                        val parent = dirFor(rel.substringBeforeLast('/', ""))
                                        val fname = rel.substringAfterLast('/')
                                        val f = parent?.createFile("application/octet-stream", fname)
                                        if (f != null) {
                                            contentResolver.openOutputStream(f.uri)?.use { out ->
                                                zis.copyTo(out)
                                            }
                                            count++
                                            written.add(rel)
                                        } else {
                                            log("Could not write: $rel")
                                        }
                                    }
                                }
                            }
                            zis.closeEntry()
                            e = zis.nextEntry
                        }
                    }
                }

                log("Done. $count files written to '$folderName'.")
                log("Files: ${written.take(12).joinToString()}${if (written.size > 12) " ..." else ""}")
                log("Force stop Minecraft, open it again, then check Dress Up.")
                toast("Replace complete")
                refreshFolder()
            } catch (e: Exception) {
                log("Error: ${e.message}")
            }
        }
    }

    // ---------------------------------------------------------------- fallback

    private fun importViaMinecraft() {
        val pack = packUri
        if (pack == null) { toast("Choose a skin pack file in Step 2 first"); return }

        io.execute {
            try {
                val folder = File(cacheDir, "shared").apply {
                    mkdirs()
                    listFiles()?.forEach { it.delete() }
                }
                val base = (queryName(pack) ?: "skinpack").substringBeforeLast('.')
                    .replace(Regex("[^A-Za-z0-9._-]"), "_")
                val out = File(folder, "$base.mcpack")
                contentResolver.openInputStream(pack)!!.use { i ->
                    out.outputStream().use { o -> i.copyTo(o) }
                }
                val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", out)

                runOnUiThread {
                    val intent = Intent(Intent.ACTION_VIEW).apply {
                        setDataAndType(uri, "application/octet-stream")
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        setPackage(mcBedrock)
                    }
                    try {
                        startActivity(intent)
                    } catch (e: ActivityNotFoundException) {
                        toast("Minecraft Bedrock is not installed or cannot import this file")
                    }
                }
            } catch (e: Exception) {
                log("Import error: ${e.message}")
            }
        }
    }
}
