# SkinSwap

Android app jo Minecraft Bedrock ke `skin_packs` folder me 4D skin pack (.mcpack / .zip) ko replace ya install karta hai. PC ke Skin Master jaisa kaam, phone ke liye.

## APK kaise banaye (GitHub Actions)

1. GitHub pe naya repo banao.
2. Is poore folder ki saari files upload karo (`.github` folder ke saath).
3. Repo me **Actions** tab kholo, **Build APK** workflow chalne do (5-8 minute).
4. Run khatam hone par neeche **Artifacts** me `SkinSwap-APK` download karo, zip kholo, `app-debug.apk` install karo.

## Use kaise kare

1. Minecraft ko force stop karo.
2. **Step 1**: `skin_packs` folder choose karo
   (`Android/data/com.mojang.minecraftpe/files/games/com.mojang/skin_packs`).
3. **Step 2**: apna 4D skin pack (.mcpack ya .zip) choose karo.
4. **Step 3**: list me se jo pack replace karna hai wo select karo, ya "Naya add karo".
5. **Replace / Install karo** dabao, phir Minecraft kholo.

## Android version ka note

- Android 10 ya kam: folder access seedha kaam karta hai.
- Android 11 aur 12: picker kabhi `Android/data` kholne deta hai, kabhi nahi, device pe depend karta hai.
- Android 13+: Google ne `Android/data` ka access third-party apps ke liye band kar diya hai, to Step 1 fail ho sakta hai. Tab **Fallback: Minecraft se import karo** button use karo. Ye pack ko Minecraft ke apne importer ko de deta hai.
